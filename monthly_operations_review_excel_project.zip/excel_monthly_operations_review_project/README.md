# Monthly Operations Review — Branch Performance Analysis

This repository contains an Excel-based monthly operations review for three store branches.

## What This Project Includes

- Profitability calculations
- Net Profit and Profit Margin % formulas
- Net Profit column chart
- Customer feedback sentiment ranking
- Manager recommendation
- Branch C cost reduction bonus scenario
- Written process explanation

## Main File

Open:

`monthly_operations_review_excel_submission.xlsx`

The main workbook includes these sheets:

1. **Executive Summary** — final submission response, chart, rankings, manager pitch, bonus result, and process explanation.
2. **Data & Calculations** — raw data plus Excel formulas.
3. **Bonus Scenario** — step-by-step Branch C 15% cost-reduction calculation.
4. **Submission Checklist** — upload and GitHub guidance.

## Submission Notes

Submit the GitHub repository link after uploading this folder. You can also upload the `.xlsx` file directly if the application asks for a project file.
