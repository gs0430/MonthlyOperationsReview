# Monthly Operations Review — Branch Performance Analysis

## Profitability

| Branch | Total Sales | Operating Cost | Net Profit | Profit Margin % |
|---|---:|---:|---:|---:|
| Branch A | $45,000 | $32,000 | $13,000 | 28.89% |
| Branch B | $38,500 | $21,000 | $17,500 | 45.45% |
| Branch C | $52,000 | $48,000 | $4,000 | 7.69% |

## Visualization

The Excel workbook includes a column chart comparing Net Profit across Branch A, Branch B, and Branch C.

## Sentiment Analysis Ranking

| Rank | Branch | Justification |
|---:|---|---|
| 1 | Branch B | Best customer experience because feedback mentions reliable stock availability and friendly staff. |
| 2 | Branch A | Positive service feedback, but long queues hurt the overall customer experience. |
| 3 | Branch C | Weakest customer experience because customers mention expensive shipping and slow delivery. |

## Manager Pitch

Branch B should receive the Performance Bonus because it has the highest net profit at $17,500, the strongest profit margin at 45.45%, and the best customer feedback. Branch A is performing reasonably well financially, but long queues show there is room to improve the customer experience. Branch C needs a Process Improvement plan because it has the highest sales but very high operating costs, leaving only $4,000 in profit and a weak 7.69% margin. Its feedback also points to shipping and delivery issues, so cost control and fulfillment efficiency should be the priority.

## Bonus Challenge

Original Operating Cost = $48,000  
Cost Reduction = $48,000 × 15% = $7,200  
New Operating Cost = $48,000 - $7,200 = $40,800  

New Net Profit = $52,000 - $40,800 = $11,200  
New Profit Margin = $11,200 / $52,000 = 21.54%

## Process Explanation

I structured the data into branch, sales, cost, and feedback fields, then used Excel formulas to calculate net profit and profit margin. Net profit shows the dollar value each branch keeps after costs, while profit margin shows efficiency relative to sales. I used a column chart to compare net profit because it clearly shows performance across separate branch categories. Finally, I ranked customer experience using the feedback text and combined the financial and qualitative findings to make the manager recommendation.
